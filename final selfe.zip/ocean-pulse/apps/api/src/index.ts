import http from 'http';
import path from 'path';
import express from 'express';
import cors from 'cors';
import { CONFIG } from './config';
import { connectDatabase, prisma } from './prisma/client';
import { requestMeta, errorHandler } from './middleware';
import apiRouter from './routes/api.routes';
import { healthCheck, readinessCheck } from './controllers/status.controller';
import { setupSocketServer, broadcastFleetState } from './realtime/socket';
import { simulator } from './simulation/simulator';

const app = express();
const server = http.createServer(app);

// 1. Basic Middleware
app.use(cors({ origin: CONFIG.corsOrigins, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(requestMeta);

// 2. Health & Readiness Root Endpoints
app.get('/health', healthCheck);
app.get('/ready', readinessCheck);

// 3. API Routes
app.use('/api/v1', apiRouter);

// 4. Serve Production Web Frontend if built (Render Single-Service Deployment)
const webDistPath = path.resolve(__dirname, '../../web/dist');
app.use(express.static(webDistPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) {
    return next();
  }
  const indexPath = path.join(webDistPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) next();
  });
});

// 5. Global Error Handler
app.use(errorHandler);

// 6. Real-time WebSockets
setupSocketServer(server);

// 7. Wire Simulator Updates to Real-time Broadcasts
simulator.setOnStateUpdate((state) => {
  broadcastFleetState(state);
});

// 8. Graceful Lifecycle & Start
async function bootstrap() {
  try {
    await connectDatabase();

    // Start background simulation loop
    simulator.start();

    server.listen(CONFIG.port, () => {
      console.log(`====================================================`);
      console.log(` OCEAN PULSE — Maritime Decision Support Platform`);
      console.log(` Server active on: http://localhost:${CONFIG.port}`);
      console.log(` Operating Mode:   ${CONFIG.demoMode ? 'DEMO MODE (Simulation Active)' : 'PRODUCTION'}`);
      console.log(` Health Endpoint:  http://localhost:${CONFIG.port}/health`);
      console.log(` API Endpoint:     http://localhost:${CONFIG.port}/api/v1`);
      console.log(`====================================================`);
    });
  } catch (err) {
    console.error('Failed to start Ocean Pulse API service:', err);
    process.exit(1);
  }
}

// Graceful shutdown handling
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

function gracefulShutdown() {
  console.log('\n[Server] Shutting down gracefully...');
  simulator.stop();
  server.close(async () => {
    await prisma.$disconnect();
    console.log('[Server] Closed all connections and database pool.');
    process.exit(0);
  });
}

bootstrap();

export { app, server };
